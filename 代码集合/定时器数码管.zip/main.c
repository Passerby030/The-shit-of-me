#include <REGX51.H>

unsigned char code number[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07,0x7F,0x6F};
unsigned int count =0;
int a =0;
int m=0;
void time()
{
	TMOD=0x01;
	TH0=0xfc;
	TL0=0x66;
	ET0=1;
	EA=1;
	TR0=1;
}
	void c() interrupt 1
	{
		TH0=0xfc;
		TL0=0x66;
		
		P2 = 0xff;
		if(a==0)
		{
			P0=number[count/10];
			P2=0xfe;
			a=1;
		}
		else
		{
			P0=number[count%10];
			P2=0xfd;
			a=0;
		}
		
		m++;
		if (m>=1000)
		{
		  count++;
			m=0;
		}
		if(count>=100)
		{
			count=0;
		}
	}
	
	void main()
	{
		time();
		while(1);
	}
	