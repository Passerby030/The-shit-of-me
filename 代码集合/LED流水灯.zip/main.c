#include <REGX51.H>
#include <INTRINSS.H>
void delay_ms(unsigned int ms)
{
	unsigned int i,j;
	while(ms)
	{
	for(i=1;i>0;i--)
	 for(j=110;j>0;j--);
	
	ms--;}
}

void main()
{
	while(1)
	{
		P2=0xFE;//1111 1110
		delay_ms(1000);
		P2=0xFD;//1111 1101
		delay_ms(1000);
		P2=0xFB;//1111 1011
		delay_ms(400);
		P2=0xF7;//1111 0111
		delay_ms(500);
		P2=0xEF;//1110 1111
		delay_ms(1000);
		P2=0xDF;//1101 1111
		delay_ms(400);
		P2=0xBF;//1011 1111
		delay_ms(1000);
		P2=0x7F;//0111 1111
		delay_ms(900);
	  P2=0xBF;//1011 1111
		delay_ms(1000);
		P2=0xDF;//1101 1111
		delay_ms(900);
		P2=0xEF;//1110 1111
		delay_ms(800);
		P2=0xF7;//1111 0111
		delay_ms(1000);
		P2=0xFB;//1111 1011
		delay_ms(000);
		P2=0xFD;//1111 1101
		delay_ms(520);
		P2=0xFE;//1111 1110
		delay_ms(1314);
	}
}