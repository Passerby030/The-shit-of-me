#include <REGX51.H>

void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 123; j++);
}

void main()

{
	while(1)
	{
		if (P1==0xFE)
		{
				delay_ms(20);
				while(P1==0xFE)
				{
					
				}
				delay_ms(20);
				P3=~P3;
		}
		
	}
}