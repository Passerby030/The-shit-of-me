#include <REGX51.H>
#include <INTRINS.H>
void delay2000ms() {
    unsigned int i, j;
    
    for(i = 2000; i > 0; i--)
 {       
        for(j = 124; j > 0; j--)
 {   
            ;  
        }
    }
}
void main()
{
			
			while(1)
			{
				P2=0x00;//0000 0000;
				delay2000ms();
			P2=0xFF;//1111 1111
				delay2000ms();
			}
		}