#include <REGX51.H>
unsigned char duan[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
unsigned int wei[]={0x01,0x02 };//0000 0001

void delay(unsigned int ms)
{
    unsigned int i, j;
    for(i = ms; i > 0; i--)
        for(j = 110; j > 0; j--);
}

void display(int number)
{
		int ten,one;
	ten=number/10;
	one=number%10;
	if (number<=9)
	{P2=0x02;
		P0=duan[number];
		delay(5);}
	else 
		{
			P2=0x01;
			P0=duan[ten];
			delay(5);
			P2=0x02;
			P0=duan[one];
			delay(5);
			
		}
	}



int scan()
{
		int a=-1;
		P3=0xff;
		P3=0xef;
		delay(5);
		switch(P3)
			{
				case 0xee:while(P3==0xee);a=1;break;//1110 1110
				case 0xed:while(P3==0xeD);a=2;break;//1110 1101
				case 0xeb:while(P3==0xeb);a=3;break;//1110 1011
				case 0xe7:while(P3==0xe7);a=4;break;//1110 0111
			}
			if(a==-1)
			{
					P3=0xdf;//1101 1111
					delay(5);
				switch(P3)
				{
					case 0xde:while(P3==0xde);a=5;break;//1101 1110
					case 0xdd:while(P3==0xdd);a=6;break;//1101 1101
					case 0xdb:while(P3==0xdb);a=7;break;//1101 1011
					case 0xd7:while(P3==0xd7);a=8;break;//1101 0111
				}
			}
				if(a==-1)
			{
					P3=0xbf;//1011 1111
					delay(5);
				switch(P3)
				{
					case 0xbe:while(P3==0xbe);a=9;break;//1011 1110
					case 0xbd:while(P3==0xbd);a=10;break;//1011 1101
					case 0xbb:while(P3==0xbb);a=11;break;//1011 1011
					case 0xb7:while(P3==0xb7);a=12;break;//1011 0111
				}
			}	
				if(a==-1)
			{
					P3=0x7f;//0111 1111
					delay(5);
				switch(P3)
				{
					case 0x7e:while(P3==0x7e);a=13;break;//0111 1110
					case 0x7d:while(P3==0x7d);a=14;break;//0111 1101
					case 0x7b:while(P3==0x7b);a=15;break;//0111 1011
					case 0x77:while(P3==0x77);a=16;break;//0111 0111
				}
			}	
			P3=0xff;
			return a;
			}

			void main()
			{
				int keyyyy;
				int key;
				P3=0xff;
				while(1)
				{
					key=scan();
					
					if(key!=-1)
					{
						keyyyy=key;
					}
					display (keyyyy);
				}
			}
