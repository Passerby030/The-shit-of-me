#include <REGX51.H>

void main()
{
			P2=0xff;//1111 1111;
}