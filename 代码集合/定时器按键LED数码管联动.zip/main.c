#include <REGX51.H>
 static bit display_flag = 0;
void delay(unsigned int ms) 
{  unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 123; j++);
}
unsigned char code number[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07,0x7F,0x6F};
unsigned int count =0;
int a =3;
int m=0;
void time()
{
	TMOD=0x01;
	TH0=0xfc;
	TL0=0x66;
	ET0=1;
	EA=1;
	TR0=1;
}
	void c() interrupt 1
{
    TH0 = 0xfc;
    TL0 = 0x66;
    
     
    
   
    P2 = 0xff;
    P0 = 0x00;
    
    
    if(display_flag == 0) {
        P0 = number[count/10];  
        P2 = 0xfe;
        display_flag = 1;
    } else {
        P0 = number[count%10]; 
        P2 = 0xfd;
        display_flag = 0;
    }
    
    
    if(a != 3) {  
        m++;
        if(m >= 1000) {  
            count++;
            m = 0;
            if(count >= 100) count = 0;
        }
    }
}
	void main()
	{
		
		time();
		while(1)
		{
		if(P3==0xfd)//1111 1101 
		{
			delay(10);
			if(P3==0xfd){
			a=1;}
			while(P3==0xfd);
			}
		if((P3 & 0x20) == 0)  
    {delay(10);
        if((P3 & 0x20) == 0)
        {
            a = 3;
            while((P3 & 0x20) == 0);
        }
        P1 = 0xfe; 
    }
    
		if (a==3)
		{
			P1=0xff;
		}
	 else
	 {
		 P1=0xfe;//1111 1110
	 }
		
   }
	}
	