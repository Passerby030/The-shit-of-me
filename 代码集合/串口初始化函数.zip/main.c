#include <REGX51.H>
#define FOSC 11059200L
#define BAUD 9600
#define TH1_VAL 0xFD

void uart(void)
{
	SCON=0x50;
	TI=0;
	TMOD&=0x0f;
	TMOD|=0x20;
	TH1=TH1_VAL;
	TL1=TH1_VAL;
	ET1=0;
	TR1=1;
}

 void send_char(unsigned char ch)
 {
	 SBUF=ch;
	 while(!TI);
	 TI=0;
 }
  void send_string(unsigned char *str)
	{
		while (*str!='\0')
		{
		send_char(*str);
			str++;
		}
	}
void main()
{
	unsigned int i;
	uart();
	while(1)
	{
		send_string("test\r\n");
		for(i=0;i<60000;i++);
	}
}
	