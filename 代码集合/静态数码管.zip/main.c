#include <REGX51.H>
unsigned char number[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67};

void delay_500ms(void)
{
    unsigned int i, j;  
    for(i=500; i>0; i--)  
    {
        for(j=110; j>0; j--);  
    }
}
void main()
		{
			while(1)
			{
				P2=number[0];
				delay_500ms();
				P2=number[1];
				delay_500ms();
				P2=number[2];
				delay_500ms();
				P2=number[3];
				delay_500ms();
				P2=number[4];
				delay_500ms();
				P2=number[5];
				delay_500ms();
				P2=number[6];
				delay_500ms();
				P2=number[7];
				delay_500ms();
				P2=number[8];
				delay_500ms();
				P2=number[9];
				delay_500ms();
			}
    }
//0110 0111