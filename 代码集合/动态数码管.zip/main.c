#include <REGX51.H>
unsigned char duan[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
unsigned int wei[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char number[]={0,1,2,3,4,5,6,7,8,9};

void delay_ms(unsigned int ms) {
    unsigned int i, j;
    
    for(i = ms; i > 0; i--) {
        
        for(j = 110; j > 0; j--);
    }
}
void main( )
{
	int a=1;
	int b=0;
	while(1)
{
switch(a){
	case 1:P0=duan[b];P2=0x01;break;
	case 2:P0=duan[b];P2=0x02;break;
	case 3:P0=duan[b];P2=0x04;break;
	case 4:P0=duan[b];P2=0x08;break;
	case 5:P0=duan[b];P2=0x10;break;
	case 6:P0=duan[b];P2=0x20;break;
	case 7:P0=duan[b];P2=0x40;break;
	case 8:P0=duan[b];P2=0x80;break;
}
  delay_ms(1000);
  P2=0x00;
   a++;
	b++;
if(a>8)a=1;
if(b>9)b=0;
	

}
}