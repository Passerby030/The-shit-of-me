#include <REGX51.H>


sbit LCD_RS = P2^0;  
sbit LCD_EN = P2^1;  


void delay(unsigned int ms)
{
    unsigned int i, j;
    for(i = ms; i > 0; i--)
        for(j = 110; j > 0; j--);
}




void LCD_Write4Bit(unsigned char dat)
{
    P0 = (P0 & 0xF0) | (dat & 0x0F);  
    
    LCD_EN = 1;
    delay(1);
    LCD_EN = 0;
    delay(1);
}


void LCD_WriteCmd(unsigned char cmd)
{
    LCD_RS = 0;  
    
    LCD_Write4Bit(cmd >> 4); 
    LCD_Write4Bit(cmd & 0x0F); 
    
    delay(2);
}


void LCD_WriteData(unsigned char dat)
{
    LCD_RS = 1;  
    
    LCD_Write4Bit(dat >> 4);  
    LCD_Write4Bit(dat & 0x0F);  
    
    delay(2);
}


void LCD_Init()
{
    delay(15);
    
   
    LCD_RS = 0;
    LCD_Write4Bit(0x03);
    delay(5);
    LCD_Write4Bit(0x03);
    delay(5);
    LCD_Write4Bit(0x03);
    delay(5);
    LCD_Write4Bit(0x02);  
    delay(5);
    
    LCD_WriteCmd(0x28);  // 4???,2?
    LCD_WriteCmd(0x0C);  // ???,???
    LCD_WriteCmd(0x06);  // ?????1
    LCD_WriteCmd(0x01);  // ??
    delay(2);
}

//============= ?????????? =============

/**
 * ????
 */
void LCD_Clear()
{
    LCD_WriteCmd(0x01);  // ????
    delay(2);
}

/**
 * ??????
 * x: ??? (0-15)
 * y: ??? (0-1)
 */
void LCD_SetCursor(unsigned char x, unsigned char y)
{
    if(y == 0)
        LCD_WriteCmd(0x80 + x);      // ???
    else
        LCD_WriteCmd(0xC0 + x);      // ???
}

/**
 * ?????
 * x: ??? (0-15)
 * y: ??? (0-1)
 * str: ???????(???'\0'??)
 */
void LCD_ShowString(unsigned char x, unsigned char y, unsigned char *str)
{
    LCD_SetCursor(x, y);
    
    while(*str != '\0')
    {
        LCD_WriteData(*str);
        str++;
    }
}

/**
 * ????(???)
 * x: ??? (0-15)
 * y: ??? (0-1)
 * num: ?????? (0-65535)
 */
void LCD_ShowNumber(unsigned char x, unsigned char y, unsigned int num)
{
	
    unsigned char i;
    unsigned char nums[5] = {0};  // ???????
    unsigned char len = 0;
    unsigned int temp = num;
    
    LCD_SetCursor(x, y);
    
    // ?????0,????0
    if(num == 0)
    {
        LCD_WriteData('0');
        return;
    }
    
    // ????????
    while(temp > 0)
    {
        nums[len] = temp % 10;
        temp = temp / 10;
        len++;
    }
    
    // ????????
    for(i = len; i > 0; i--)
    {
        LCD_WriteData(nums[i-1] + '0');
    }
}
int scan()
{
		int a=-1;
		P3=0xff;
		P3=0xef;
		delay(5);
		switch(P3)
			{
				case 0xee:while(P3==0xee);a=1;break;//1110 1110
				case 0xed:while(P3==0xeD);a=2;break;//1110 1101
				case 0xeb:while(P3==0xeb);a=3;break;//1110 1011
				case 0xe7:while(P3==0xe7);a=4;break;//1110 0111
			}
			if(a==-1)
			{
					P3=0xdf;//1101 1111
					delay(5);
				switch(P3)
				{
					case 0xde:while(P3==0xde);a=5;break;//1101 1110
					case 0xdd:while(P3==0xdd);a=6;break;//1101 1101
					case 0xdb:while(P3==0xdb);a=7;break;//1101 1011
					case 0xd7:while(P3==0xd7);a=8;break;//1101 0111
				}
			}
				if(a==-1)
			{
					P3=0xbf;//1011 1111
					delay(5);
				switch(P3)
				{
					case 0xbe:while(P3==0xbe);a=9;break;//1011 1110
					case 0xbd:while(P3==0xbd);a=10;break;//1011 1101
					case 0xbb:while(P3==0xbb);a=11;break;
				}
			}	
			P3=0xff;
			return a;
			}

void main()
{

int true=1111;
int num=1;
int Password;
int p=1;
LCD_Init()//��ʼ��
LCD_ShowString(0, 0, "Password:");
while(1)
{
	num=scan();//��ȡ����ֵ
		if(num>0)
		{
			if(p<=4)//��������λ��
			{
				Password=Password*10+num;//�����洢������ݽ�
				LCD_ShowNumber(4,1,Password);
			}
			p++;//��������λ��
		}
		if(num==10)//ȷ�ϼ�
		{
			if(Password==1111)//����
			{
				LCD_ShowString(12,1, "true");
			}
			else
			{
				LCD_ShowString(11,1, "false");
			}
		}
		if(num==11)//��ռ�
		{
			LCD_Clear();
			LCD_ShowString(0, 0, "Password:");
			Password=0;
			p=1;//�����������
		}
}
}