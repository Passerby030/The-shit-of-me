#include <REGX51.H>
sbit bit1 = P2^0;  
sbit bit2 = P2^1;  
sbit bit3 = P2^2;  
sbit bit4 = P2^3;  
sbit bit5 = P2^4;  
sbit bit6 = P2^5;  
sbit a=P3^2;
sbit b=P3^3;
sbit S=P1^0;
sbit SS=P1^3;
sbit SSS=P1^6;
int total=0;
unsigned char code number[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};//С����Ϊ10000000
unsigned char sec=0;
unsigned int ms=0;
int run=0;
int flaga=0;
int flagb=0;
void delay(unsigned int mms) {
    unsigned int i, j;
    for(i=0; i<mms; i++)
        for(j=0; j<123; j++); 
}
int keyscan(int key)
{
	int state =0;
	if(key==0)
		{
			delay(2);
			if(key==0)
			{
				state=1;
				
			}
}
		return state;
		}
void time_Init()
{
	TMOD|=0x01;//������ģʽ
	TH0=0xfc;
	TL0=0x18;
	ET0=1;
	EA=1;
	TR0=1;
}
void Timer0_ISR(void) interrupt 1 
	{
		
    TH0 = 0xFC;
    TL0 = 0x18;
    TH0 = (65536 - 1000) / 256;
    TL0 = (65536 - 1000) % 256;
    if(run==1)
		{	
    ms++;
    if(ms >= 700) 
			{  
        ms = 0;
        sec++;
        if(sec >= 60) 
					{ 
            sec = 0;
        }
    }
   }
		}
void display(){
    
    bit1 = 1; bit2=1; bit3=1; bit4=1; bit5=1; bit6=1; 
    P0 = 0x00; 
    bit1 = 0;  
    P0 = number[sec/10];
    delay(1);
    bit1 = 1; 
    P0 = 0x00;
    bit2 = 0; 
    P0 = number[sec%10];
    delay(1);
    
  
    bit2 = 1;
    P0 = 0x00;
    bit3 = 0;
    P0 = 0x80; // ֻ��С����
    delay(1);
    
    
    bit3 = 1;
    P0 = 0x00;
    bit4 = 0;
    P0 = number[ms/100];
    delay(1);
    
    
    bit4 = 1;
    P0 = 0x00;
    bit5 = 0;
    P0 = number[(ms/10)%10];
    delay(1);
    
   
    bit5 = 1;
    P0 = 0x00;
    bit6 = 0;
    P0 = number[ms%10];
    delay(1);
    
    
    bit6 = 1;
    P0 = 0x00;
}
	void main(void) {
    time_Init(); 
			run=0;
    while(1) {
			total=1000*sec+ms;
				if(keyscan(a)==1&&flaga==0)
				{
					run=!run;
					S=1;
					SS=1;
					SSS=1;
					flaga=1;
				}
				else if(a==1)
				{
				flaga=0;
				}
				if(keyscan(b)==1&&flagb==0)
				{
					run=0;
					ms=0;
					sec=0;
					flagb=1;
					S=1;
					SS=1;
					SSS=1;
				}    
					else if(b==1)
					{
						flagb=0;
					}
			if(run==0)
			{
				
				if(total>8000&&total<12000)
				{
					S=0;
					if(total>9500&&total<10500)
					{
						S=0;SS=0;
						if(total>9800&&total<10200)
						{
							S=0;SS=0;SSS=0;
						}				
				} 
				 
    }
	}
			display();
}
		}